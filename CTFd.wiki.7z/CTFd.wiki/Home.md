![CTFd logo](https://raw.githubusercontent.com/CTFd/CTFd/master/CTFd/themes/core/static/img/logo.png)

**Welcome to CTFd** — the easy to use CTF framework that powers CSAW CTF. 

This wiki is where you can find information on deploying CTFd and efficiently running your CTF.

**Basic Installation:**
 1. `./prepare.sh` to install dependencies using apt.
 2. Modify [CTFd/config.py](https://github.com/isislab/CTFd/blob/master/CTFd/config.py) to your liking.
 3. Use `python serve.py` in a terminal to drop into debug mode.
 4. [Here](http://flask.pocoo.org/docs/0.10/deploying/) are some Flask deployment options.
 5. [Here](https://github.com/CTFd/CTFd/wiki/Basic-Deployment) are some deployment options for CTFd.
 6. You can check out the [Getting Started](https://github.com/CTFd/CTFd/wiki/Getting-Started) guide for a breakdown of some of the features you need to get started. 

**CTFTime Integration:**

CTFd supports the [CTFTime minimal scoreboard feed feature](https://ctftime.org/json-scoreboard-feed) by keeping the `/scores` endpoint inline with the CTFTime requirements. This means that you merely need to provide CTFTime `http://<CTF_URL>/scores` for CTFTime to have your CTF's scoreboard. `/scores` is also used by CTFd for its own scoreboard updates. 

**Plugins**

CTFd supports the loading of plugins which can modify the Flask app without modifying the main application. These can be dropped into [the plugins folder](https://github.com/isislab/CTFd/tree/master/CTFd/plugins) which will be loaded on application start. 

If you're interested in developing a plugin, you can read more about the plugin architecture on the [Plugins page](https://github.com/CTFd/CTFd/wiki/Plugins).

Here are some example plugins:
* [CTFd Amazon S3 Plugin](https://github.com/CTFd/CTFd-S3-plugin)
* [CTFd Docker Plugin](https://github.com/CTFd/CTFd-Docker)
* [CTFd Push Notifications](https://github.com/CTFd/CTFd-Notify)
* [Dynamic Scoring](https://github.com/CTFd/DynamicValueChallenge)

**Themes**

CTFd supports themes! If you modify the [original theme](https://github.com/CTFd/CTFd/tree/master/CTFd/themes/original) and throw it into the [themes](https://github.com/CTFd/CTFd/tree/master/CTFd/themes) folder, you will be able to change the theme from the admin configuration panel. The admin panel itself can also be customized by modifying the admin theme folder.

A repository to track open source CTFd themes is available [here](https://github.com/CTFd/themes). Premium CTFd themes are available [here](https://ctfd.io/store)