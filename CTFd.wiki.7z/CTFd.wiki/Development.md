# Development

Typically while developing CTFd, developers use the provided `serve.py` script and access CTFd at `http://localhost:4000`. 

Very often you will need to generate testing data so that you can exercise CTFd's behavior. The included `populate.py` script will insert randomized testing data into the CTFd database. 

# Testing

To run CTFd's tests you should install the testing modules with:

`pip install -r development.txt`

Then run nose with the following from root project directory:

`nosetests`

To run a single test you can run something similar to: 

`nosetests tests.test_utils:test_ctf_started`

Although there isn't much debugging information in the tests you can see print messages if you run: 

`nosetests -s`

In addition, if you create a pull request, Travis will validate that your code is PEP8 compliant with `pep8 --ignore E501,E712 CTFd/ tests/`. 

# Reset

If you need to wipe CTFd completely, the simplest way is often to just delete the database (CTFd/ctfd.db by default) and remove the contents of the `CTFd/uploads` folder. 
