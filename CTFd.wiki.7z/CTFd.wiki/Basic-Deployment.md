CTFd can be deployed as a standard wsgi application. However, the simplest means of deploying a CTFd instance is to use Docker Compose.

1. Install [Docker](https://docs.docker.com/install/)
2. Install [Docker Compose](https://docs.docker.com/compose/install/)
1. Clone the CTFd repository with `git clone https://github.com/CTFd/CTFd.git`
2. Modify the `docker-compose.yml` file from the repository to specify a `SECRET_KEY` environment for the CTFd service.
    * You can also run `python -c "import os; f=open('.ctfd_secret_key', 'a+'); f.write(os.urandom(64)); f.close()"` within the CTFd repo to generate a .ctfd_secret_key file.
```
  environment:
    - SECRET_KEY=<SPECIFY_RANDOM_VALUE>
    - UPLOAD_FOLDER=/var/uploads
    - LOG_FOLDER=/var/log/CTFd
    - DATABASE_URL=mysql+pymysql://root:ctfd@db/ctfd
    - REDIS_URL=redis://cache:6379
    - WORKERS=4
```
3. Run `docker-compose up`
4. You should now be able to access CTFd at http://localhost:8000

If you're interested in a more advanced deployment read the [Advanced Deployment](https://github.com/CTFd/CTFd/wiki/Advanced-Deployment) page or contact [support@ctfd.io](mailto:support@ctfd.io) for an Enterprise Deployment.